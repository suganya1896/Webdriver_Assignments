package coding.exercise;

import java.time.Duration;
import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
//completed
public class SalesForcePage {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(options);
		
		driver.get("https://login.salesforce.com/?locale=in");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElementByXPath("//div[@id='username_container']//input").sendKeys("hari.radhakrishnan@testleaf.com");
		driver.findElementById("password").sendKeys("India$123");
		driver.findElementByXPath("//input[@class='button r4 wide primary']").click();
		
		Thread.sleep(8000);
		driver.findElementByXPath("//div[@class='slds-icon-waffle']").click();
		
	 WebElement view=driver.findElementByXPath("//button[text()='View All']");
	 
	 Actions builder=new Actions(driver);
	 builder.moveToElement(view).click().perform();
	 
	WebElement service=driver.findElementByXPath("//p[text()='Service Console']");
	
	builder.moveToElement(service).click().perform();
	
	driver.findElementByXPath("//div[@data-aura-class='oneAppNavMenu']//lightning-primitive-icon").click();
	WebElement products=driver.findElementByXPath("//span[text()='Products']");
	Thread.sleep(2000);
	builder.moveToElement(products).click().perform();
	
	
	WebElement newbutton=driver.findElementByXPath("//div[text()='New']");
	//builder.moveToElement(newbutton).click().perform();
	
	WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
	wait.until(ExpectedConditions.elementToBeClickable(newbutton));
	
	newbutton.click();
	driver.findElementByXPath("//div[@class='uiInput uiInputText uiInput--default uiInput--input']//input")
	.sendKeys("Metal Materials");
	
	driver.findElementByXPath("//div[@class='uiInput uiInputCheckbox uiInput--default uiInput--checkbox']//input").click();
	driver.findElementByXPath("(//span[text()='Save'])[2]").click();
	
	
	//to locate pop up which will appear only for few seconds in screen , press f8 to stop screen & go source ,locate the element
	
	WebElement popup=driver.findElementByXPath("//span[@class='toastMessage slds-text-heading--small forceActionsText']");
	
	wait.until(ExpectedConditions.visibilityOf(popup));
	String popupText=popup.getText();
	
	System.out.println("message present in pop -up:"+popupText);
	
	
	wait.until(ExpectedConditions.invisibilityOf(popup));
	
	WebElement productName=driver.findElementByXPath("((//div[@data-component-id='force_detailPanel'])[6]//span)[3]");
	
	String ExpectedPN=productName.getText();
	System.out.println("Created product name:"+ExpectedPN);
	if(ExpectedPN.equalsIgnoreCase("Metal Materials"))
		System.out.println("product name matched");
	else
		System.out.println("product name mismatch");
	
	driver.findElementByXPath("//div[text()='New Contact']").click();
	
	
	//click on salutation drop down
	
	driver.findElementByXPath("(//a[text()='--None--'])[2]").click();
	
	
	driver.findElementByXPath("//input[@class='firstName compoundBorderBottom form-element__row input']").sendKeys("Ramya");
	driver.findElementByXPath("//input[@class='lastName compoundBLRadius compoundBRRadius form-element__row input']").sendKeys("karan");
	driver.findElementByXPath("//div[@class='autocompleteWrapper slds-grow']/input").sendKeys("b",Keys.TAB);
	
	driver.findElementByXPath("(//div[@class='uiInput uiInputText uiInput--default uiInput--input']/input)[5]").sendKeys("xyz");
	
	driver.findElementByXPath("//button[@class='slds-button slds-button_brand cuf-publisherShareButton undefined uiButton']/span").click();
	
	
	driver.findElementByXPath("//div[text()='New Opportunity']").click();
	
	
	driver.findElementByXPath("//span[text()='Opportunity Name']/following::input").sendKeys("Test opportunity");
	driver.findElementByXPath("//span[text()='Opportunity Name']/following::input[2]").sendKeys("b",Keys.TAB);
	
	LocalDate today=LocalDate.now();
	int date=today.getDayOfMonth();
	
	int s=date+1;
	driver.findElementByXPath("//a[@class='datePicker-openIcon display']").click();
	driver.findElementByXPath("//td[@class='uiDayInMonthCell']/span[text()='"+s+"']").click();
	
	driver.findElementByXPath("(//a[text()='--None--'])[2]").click();
	
	WebElement stage=driver.findElementByXPath("//a[text()='Needs Analysis']");
	builder.moveToElement(stage).click().perform();
	
	driver.findElementByXPath("(//span[text()='Save'])[4]").click();
	driver.findElementByXPath("//div[text()='New Case']").click();
	
	driver.findElementByXPath("//input[@title='Search Contacts']").sendKeys("ramya",Keys.TAB);
	driver.findElementByXPath("(//a[text()='--None--'])[2]").click();
	
	builder.moveToElement(driver.findElementByXPath("//a[text()='New']")).click();
	
	driver.findElementByXPath("(//span[text()='Save'])[4]").click();
	
	
	
	driver.close();	
	}

}
