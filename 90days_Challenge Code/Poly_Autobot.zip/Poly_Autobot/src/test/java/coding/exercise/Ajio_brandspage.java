package coding.exercise;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Ajio_brandspage {

	public static void main(String[] args) {
		
		
		WebDriverManager.chromedriver().setup();
		 ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notificaions");;
		
		ChromeDriver driver=new ChromeDriver(options);
		driver.get("https://www.ajio.com/");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Actions builder=new Actions(driver);
		
		WebElement women=driver.findElementByXPath("//a[text()='WOMEN']");
		builder.moveToElement(women).perform();;
		WebElement brand=driver.findElementByXPath("(//a[text()='BRANDS'])[2]");
		
		builder.moveToElement(brand).perform();
		
		//(//a[text()='BRANDS'])[2]/following::div[@class='items']/span/a
		
		
		
		driver.close();
		
	}

}
