package coding.exercise;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class paytmmall_Page {

	public static void main(String[] args) throws InterruptedException {
		
	
	
		WebDriverManager.firefoxdriver().setup();
		FirefoxOptions options=new FirefoxOptions();
		options.addArguments("--disable-notifications");
		FirefoxDriver driver=new FirefoxDriver(options);
		
		driver.get("https://paytmmall.com/");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(5000);

		driver.findElementByXPath("//span[text()='Shop By Category']").click();
		
		WebElement TV=driver.findElementByXPath("//a[text()='TVs & Appliances']");
		WebElement AirPurifier=driver.findElementByXPath("//a[text()='Air Purifiers']");	
		
		Actions builder=new Actions(driver);
		Thread.sleep(2000);
		builder.moveToElement(TV).perform();
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(AirPurifier));
		builder.moveToElement(AirPurifier).click().perform();
				
		WebElement minPrice=driver.findElementByXPath("//input[@placeholder='Min']");
		minPrice.clear();
		
		minPrice.sendKeys("5000");
		

		WebElement maxPrice=driver.findElementByXPath("//input[@placeholder='Max']");
		
		maxPrice.clear();
		maxPrice.sendKeys("15000",Keys.ENTER);
		
		driver.findElementByXPath("//span[text()='Sort by ']").click();
		
		driver.findElementByXPath("//div[@class='_3vL1 _2gwg']").click();
		
		driver.findElementByXPath("//div[@class='UGUy']").click();
		
		Set<String> win= driver.getWindowHandles();
		List<String> winList=new ArrayList<String>(win);
		driver.switchTo().window(winList.get(0));
		
		driver.findElementByXPath("//span[text()='Select EMI']").click();
		
		
		
		
		
		
		
	}

}
