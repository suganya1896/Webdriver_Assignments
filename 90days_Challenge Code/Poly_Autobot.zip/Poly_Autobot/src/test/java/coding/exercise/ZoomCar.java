package coding.exercise;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ZoomCar {
	@Test
	public void add()
	
	{
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.walmart.com/");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//button[@id='header-Header-sparkButton']//img").click();
		WebElement cloth=driver.findElementByXPath("//span[text()='Clothing, Shoes & Accessories']");
		Actions builder=new Actions(driver);
		builder.moveToElement(cloth).click().perform();
		
        WebElement shoes=driver.findElementByXPath("//div[text()='Shoes']");
		
		//Actions builder=new Actions(driver);
		builder.moveToElement(shoes).click().perform();
		driver.findElementByXPath("(//a[text()='Comfort Shoes'])[3]").click();
		driver.findElementByXPath("//a[text()='Sneakers']").click();
		
		//locating all product title 
		 
		 List<WebElement> Title=driver.findElementsByXPath("//span[@class='product-brand']/strong");
		 //printing size of list
		System.out.println("No of products available in page:"+Title.size());
		//looping through all products to pick only "flexx" & "Propet" brand
		
		for(int i=0;i<Title.size();i++)
		{
			//if element present inside list has visible text as "flex" & "propet" ,then add that product to map
			
		String product=	Title.get(i).getText();
		
		 if(product.equalsIgnoreCase("The Flexx")||product.equalsIgnoreCase("Propet"))
		 {
			//Map<String,String>	PDetails=new 
	        List<WebElement> price=driver.findElementsByXPath("//span[@class='search-result-productprice gridview enable-2price-2']");
	     for (WebElement e : price) {
			
	    	 price.add(e);
	    }    
		 System.out.println(price);

	}
}
		
	}
}
