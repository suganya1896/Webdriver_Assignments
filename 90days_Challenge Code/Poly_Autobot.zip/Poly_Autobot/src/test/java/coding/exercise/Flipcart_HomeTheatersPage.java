package coding.exercise;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Flipcart_HomeTheatersPage {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.firefoxdriver().setup();
		FirefoxOptions options=new FirefoxOptions();
		options.addArguments("--disable-notifications");
		FirefoxDriver driver=new FirefoxDriver(options);
		
		driver.get("https://www.flipkart.com/");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//button[@class='_2KpZ6l _2doB4z']").click();
		driver.findElementByXPath("//input[@title='Search for products, brands and more']").sendKeys("home theaters",Keys.ENTER);
		Thread.sleep(2000);
		//getting total count of products displayed in page
		String totalproducts=driver.findElementByXPath("//span[@class='_10Ermr']").getText();
		System.out.println("before filtering :"+totalproducts);
		//click on check box of 4* & above rating
		driver.findElementByXPath("//div[@class='_4921Z t0pPfW']//div[@class='_24_Dny']").click();
		Thread.sleep(2000);
		System.out.println("after filtering:"+totalproducts);
		//click on "price high to low"
		
		WebElement PF=driver.findElementByXPath("//div[@class='_10UF8M'][3]");
		PF.click();
		//get the color of text
		String ActualColor=PF.getCssValue("color");
		
		System.out.println("Color code of field:"+ActualColor);
		
		 //Use Color present under "org.openqa.selenium.support.Color package"
		//class to convert the value from rgba() to Hex code and store in a variable
        String hexColorValue = Color.fromString(ActualColor).asHex();
        System.out.println("Actual color code from converting to hex:"+hexColorValue);
		String ExpectedColor="#2874f0";
		System.out.println("Expected color:"+ExpectedColor);
		
		Assert.assertEquals(hexColorValue, ExpectedColor);
		
		
		//confirm all products are sorted based on price filter
		List<WebElement> price=driver.findElementsByXPath("//div[@class='_25b18c']//div[@class='_30jeq3']");
		
		List<Integer> priceList=new ArrayList<Integer>();
		for(int i=0;i<price.size();i++)
		{
			String s=price.get(i).getText();
			int PP=Integer.parseInt(s);
			priceList.add(PP);
		}
		
		System.out.println(priceList);
		
		for(int j=4;j<=6;j=j+2)
		{
		WebElement hoverOnProduct=driver.findElementByXPath("//a[@class='_8VNy32']");
		Actions builder=new Actions(driver);
		builder.moveToElement(hoverOnProduct).perform();
	    WebElement compare=	driver.findElementByXPath("(//div[text()='No Cost EMI']/following::div[@class='_24_Dny'])["+j+"]");
		//.getText()
		
		compare.click();
		}
		
		driver.findElementByXPath("//span[text()='COMPARE']").click();
		
		
		
		driver.close();
		
		
		
		
		
		
	}

}
