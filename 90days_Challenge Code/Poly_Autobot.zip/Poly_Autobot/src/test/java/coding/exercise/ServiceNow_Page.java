package coding.exercise;

import java.time.Duration;
import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ServiceNow_Page {

	public static void main(String[] args) throws InterruptedException {
		
	/*	WebDriverManager.firefoxdriver().setup();
		FirefoxOptions options=new FirefoxOptions();
		options.addArguments("--disable-notifications");
		FirefoxDriver driver=new FirefoxDriver(options); */
		
		WebDriverManager.chromedriver().setup();
		 ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notificaions");;
		
		ChromeDriver driver=new ChromeDriver(options);
		
		driver.get("https://dev96572.service-now.com/");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.switchTo().frame("gsft_main");
		driver.findElementById("user_name").sendKeys("admin");
		driver.findElementById("user_password").sendKeys("Tuna@123");
		
		driver.findElementByXPath("//button[text()='Login']").click();
		
		String HomePagetitle="System Administration | ServiceNow";
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(60));
		
		wait.until(ExpectedConditions.titleContains(HomePagetitle));
		
		driver.findElementByXPath("//input[@id='filter']").sendKeys("Oauth",Keys.ENTER);
		
		driver.findElementByXPath("//div[text()='Application Registry']").click();
		driver.switchTo().frame("gsft_main");
		WebElement newButton=driver.findElementByXPath("//button[@class='selected_action action_context btn btn-primary']");
		Actions builder=new Actions(driver);
		builder.moveToElement(newButton).click().perform();
	
		driver.findElementByXPath("//div[@class='container-fluid wizard-container']/a").click();
		
		LocalDate today=LocalDate.now();
         int Date = today.getDayOfMonth();
         int year = today.getYear();
         int month = today.getMonthValue();
         
         String s="Suganya_";
         
		driver.findElementById("oauth_entity.name").sendKeys("sample1_11302020");
		
		//String clientID=driver.findElementById("oauth_entity.client_id").getAttribute("value");
		driver.findElementByXPath("(//button[text()='Submit'])[2]").click();
		/*WebElement search=driver.findElementByXPath("form-control default-focus-outline");
		
		Select dd=new Select(search);
		dd.selectByVisibleText("Name"); */
		
		driver.findElementByXPath("(//label[text()='Search'])[2]/following::input").sendKeys("sample1",Keys.ENTER);
		Thread.sleep(3000);
		String ClientName=driver.findElementByXPath("(//tbody[@class='list2_body']//td)[3]/a").getText();
		
		if(ClientName.contains("sample"))
			System.out.println("Client is created");
		else
			System.out.println("Client is not created");
		
		driver.close();
		
	}

}
