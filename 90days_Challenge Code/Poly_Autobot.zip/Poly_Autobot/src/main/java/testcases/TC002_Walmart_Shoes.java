package testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.Walmart_HomePage;

public class TC002_Walmart_Shoes extends ProjectSpecificMethods{
	
	
	
	@Test
	public void shoes()
	{
		
		WebElement cloth=new Walmart_HomePage(driver).clickMenu().clickClothing();
		
		new Walmart_HomePage(driver).moveToElement(cloth).clickShoes().clickComfortShoes().clickSneakers()
		.getLowPriceProduct();
	}

	
}
