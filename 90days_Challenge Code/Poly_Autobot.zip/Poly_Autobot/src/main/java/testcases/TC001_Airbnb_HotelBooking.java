package testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.Airbnb_HomePage;

public class TC001_Airbnb_HotelBooking  extends ProjectSpecificMethods{
	
	
	@Test
	public void bookRoom() throws InterruptedException
	{
		
		int currentDateofMonth=new Airbnb_HomePage(driver).getDate();
		WebElement location=new Airbnb_HomePage(driver).
				enterLocation("Baga");
		
		new Airbnb_HomePage(driver).moveToElement(location).clickOk().clickCheckIn();
		
		
		WebElement checkIN=new Airbnb_HomePage(driver)
			.selectCheckInDate(currentDateofMonth);
		WebElement checkOut=new Airbnb_HomePage(driver).moveToElement(checkIN)
		.selectCheckOutDate(currentDateofMonth);
		
		String checkInDate=
		new Airbnb_HomePage(driver).moveToElement(checkOut)
		.clickCheckBox()
		//.selectMydatesFLX()
		.getCheckInDate();
		
		String checkOutDate=new Airbnb_HomePage(driver).getCheckOutDate();
		new Airbnb_HomePage(driver).clickAddGuest()
		.addAdults_Kids()
		.clickSearch().clickPlace().selectRoom().clickSave().clickPrice()
		.enterMinPrice().enterMaxPrice().clickSave().clickFilters().addBeds()
		.addBedrooms().clickShowStays().clickFirstHotel().switchToChild().getPrice()
		.verifyDate(checkInDate, checkOutDate);
		
	}

}
