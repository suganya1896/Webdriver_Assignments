package testcases;

//completed
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.ZoomCar_HomePage;

public class TC004_ZoomCar extends ProjectSpecificMethods{

	@Test
	public void bookCar() throws InterruptedException
	{
		new ZoomCar_HomePage(driver).clickJourney().clickStartLoc().clickNext().selectDate()
		.clickNext().confirmSelectedDate().clickDone().getCarDetail_Price().clickBookNow();
	}
	
}
