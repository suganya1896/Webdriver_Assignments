package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class ZoomCar_HomePage extends ProjectSpecificMethods{
	
	public ZoomCar_HomePage(RemoteWebDriver driver) {
		
		this.driver=driver;
	}
	
	public ZoomCar_BookCarPage clickJourney()
	{
		driver.findElementByLinkText("Start your wonderful journey").click();
		return new ZoomCar_BookCarPage(driver);
	}

}
