package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class Airbnb_BagaBeachPage extends ProjectSpecificMethods{
	
public Airbnb_BagaBeachPage(RemoteWebDriver driver) {
		
		this.driver=driver;
	
	}


public Airbnb_BagaBeachPage clickPlace()
{
	driver.findElementByXPath("//span[text()='Type of place']").click();
	
	return this;
}

public Airbnb_BagaBeachPage selectRoom()
{
	driver.findElementByXPath("(//span[@class='_167krry'])[3]").click();
	return this;
	
}
public Airbnb_BagaBeachPage clickSave()
{
	driver.findElementByXPath("//button[text()='Save']").click();
	
	return this;
}

public Airbnb_BagaBeachPage clickPrice() throws InterruptedException
{
	driver.findElementByXPath("//span[text()='Price']").click();
	Thread.sleep(1000);
	return this;
}

public Airbnb_BagaBeachPage enterMinPrice() throws InterruptedException
{
	//WebElement min=driver.findElementByXPath("//div[@class='_fywymp7']");
	//min.clear();
	//WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
	//wait.until(ExpectedConditions.invisibilityOf(min));
	/*if we couldn't able to interacte with field & getting "Invalid element State exception ,the use java script
	executor to directly pass values to field in page */
	JavascriptExecutor js=(JavascriptExecutor)driver;

	js.executeScript("document.getElementById('price_filter_min').value = '1000';");
			
			return this;
}

public Airbnb_BagaBeachPage enterMaxPrice() throws InterruptedException
{
	//WebElement max=driver.findElementById("price_filter_max");
	//max.clear();
	JavascriptExecutor js=(JavascriptExecutor)driver;

	js.executeScript("document.getElementById('price_filter_max').value = '10000';");
			
	return this;

}

public Airbnb_BagaBeachPage clickFilters()
{
	driver.findElementByXPath("//span[text()='More filters']").click();
	return this;
}


public Airbnb_BagaBeachPage addBeds()
{
	for(int i=0;i<=1;i++)
	{
		driver.findElementByXPath("//div[@class='_jwbbkz']//button[2]").click();
	}
	
	return this;
}

public Airbnb_BagaBeachPage addBedrooms()
{
	driver.findElementByXPath("(//div[@class='_jwbbkz']//button[2])[2]").click();
	return this;
}

public Airbnb_BagaBeachPage clickShowStays()
{
	driver.findElementByXPath("//button[@data-testid='more-filters-modal-submit-button']").click();
	
	return this;
}

public Airbnb_BagaBeachPage clickFirstHotel()
{
	driver.findElementByXPath("//div[@class='_1048zci']/a").click();
	return this;
}

public Airbnb_BagaBeachPage switchToChild()
{
	Set<String> window=driver.getWindowHandles();
	List<String> list=new ArrayList<String>(window);
	
	driver.switchTo().window(list.get(1));
	System.out.println("title of new window:"+driver.getTitle());
	return this;
}

public Airbnb_BagaBeachPage getPrice()
{
	WebElement price=driver.findElementByXPath("(//span[@class='_pgfqnw'])[2]");
	System.out.println("Price for One Night:"+price.getText());
	
	return this;
}

public void verifyDate(String CheckIn,String CheckOut)
{
	String COD=driver.findElementByXPath("//div[text()='Checkout']/following-sibling::div").getText();
	String CID=driver.findElementByXPath("//div[text()='Check-in']/following-sibling::div").getText();
	System.out.println("check in date"+CID+"check out date is "+COD);
	if(CID.contains(CheckIn))
		System.out.println("Check In Date matched as per given detail");
	else
		System.out.println("Check In Date mismatch");
	
	if(COD.contains(CheckOut))
		System.out.println("Check Out Date matched as per given detail");
	else
		System.out.println("Check Out Date mismatch");
	
}
}
