package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class SalesForceLoginPage extends ProjectSpecificMethods {
	
	public SalesForceLoginPage(RemoteWebDriver driver) {
		this.driver=driver;
	}

	public SalesForceLoginPage enterUsername()
	{

		driver.findElementByXPath("//div[@id='username_container']//input").sendKeys("hari.radhakrishnan@testleaf.com");
		return this;
	}
	
	public SalesForceLoginPage enterPassword()
	{
		driver.findElementById("password").sendKeys("India$123");
		
		return this;
	}
	
	public SalesForce_HomePage clickLogin() throws InterruptedException
	{
    driver.findElementByXPath("//input[@class='button r4 wide primary']").click();
		
		Thread.sleep(8000);
		
		return new SalesForce_HomePage(driver);
	}
}
