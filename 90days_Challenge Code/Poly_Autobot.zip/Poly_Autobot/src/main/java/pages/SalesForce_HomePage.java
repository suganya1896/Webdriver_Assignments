package pages;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class SalesForce_HomePage extends  ProjectSpecificMethods {

	public SalesForce_HomePage(RemoteWebDriver driver) {
		this.driver=driver;
	}

	public static WebDriverWait wait;

	public WebElement clickMenu()
	{
		driver.findElementByXPath("//div[@class='slds-icon-waffle']").click();
		
		 WebElement view=driver.findElementByXPath("//button[text()='View All']");
		 
		 
		return view;
	}
	
	public SalesForce_HomePage MoveToElement(WebElement ele)
	{
		Actions builder=new Actions(driver);
		 builder.moveToElement(ele).click().perform();
		 
		 return this;
	}
	
	public  WebElement clickServiceConsole() {
		WebElement service=driver.findElementByXPath("//p[text()='Service Console']");
		
		return service;
		
	}
	
	public SalesForce_HomePage clickAppMenu()
	{
		driver.findElementByXPath("//div[@data-aura-class='oneAppNavMenu']//lightning-primitive-icon").click();
		return this;
	}
	
	public WebElement selectProduct() throws InterruptedException
	{
		WebElement products=driver.findElementByXPath("//span[text()='Products']");
		Thread.sleep(6000);
		
		return products;
	}
	
	public SalesForce_HomePage clickNew()
	{
		WebElement newbutton=driver.findElementByXPath("//div[text()='New']");
		//builder.moveToElement(newbutton).click().perform();
		
		wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(newbutton));
		
		newbutton.click();
		
		return this;
	}
	
	
	public SalesForce_HomePage enterProductDetails()
	{
		driver.findElementByXPath("//div[@class='uiInput uiInputText uiInput--default uiInput--input']//input")
		.sendKeys("Metal Materials");
		
		driver.findElementByXPath("//div[@class='uiInput uiInputCheckbox uiInput--default uiInput--checkbox']//input").click();
		driver.findElementByXPath("(//span[text()='Save'])[2]").click();
		
		return this;
	}
	
	public SalesForce_HomePage capturePopUpMSG()
	{
		//to locate pop up which will appear only for few seconds in screen , press f8 to stop screen & go source ,locate the element
		
		WebElement popup=driver.findElementByXPath("//span[@class='toastMessage slds-text-heading--small forceActionsText']");
		
		wait.until(ExpectedConditions.visibilityOf(popup));
		String popupText=popup.getText();
		
		System.out.println("message present in pop -up:"+popupText);
		
		
		wait.until(ExpectedConditions.invisibilityOf(popup));

		return this;
	}
	
	
	public SalesForce_ProductPage verifyProductname()
	{
		WebElement productName=driver.findElementByXPath("(//span[@class='test-id__field-label'])[8]/following::span[2]");
		
		String ExpectedPN=productName.getText();
		
		System.out.println("Created product name:"+ExpectedPN);
		
		/*if(ExpectedPN.contains("Metal"))
			System.out.println("product name matched");
		else
			System.out.println("product name mismatch"); */
		
		return new SalesForce_ProductPage(driver);
	}
}
