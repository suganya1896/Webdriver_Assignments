package pages;

import java.time.LocalDate;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class SalesForce_ProductPage extends ProjectSpecificMethods {

	
	public SalesForce_ProductPage(RemoteWebDriver driver) {
		
		this.driver=driver;
	}
	
	
	Actions builder=new Actions(driver);
	
	public SalesForce_ProductPage clickNewContact()
	{
		driver.findElementByXPath("//div[text()='New Contact']").click();
		
		return this;
	}
	
	public SalesForce_ProductPage enterContactDetails()
	{
		//click on salutation drop down
		driver.findElementByXPath("(//a[text()='--None--'])[2]").click();
		
		//to enter firstname
		driver.findElementByXPath("//input[@class='firstName compoundBorderBottom form-element__row input']").sendKeys("Ramya");
		//to enter lastname
		driver.findElementByXPath("//input[@class='lastName compoundBLRadius compoundBRRadius form-element__row input']").sendKeys("karan");
		//select accounts name from predefined list
		driver.findElementByXPath("//div[@class='autocompleteWrapper slds-grow']/input").sendKeys("b",Keys.TAB);
		//to enter title
		driver.findElementByXPath("(//div[@class='uiInput uiInputText uiInput--default uiInput--input']/input)[5]").sendKeys("xyz");
		
		return this;
	}
	
	public SalesForce_ProductPage clickSave()
	{
		driver.findElementByXPath("//button[@class='slds-button slds-button_brand cuf-publisherShareButton undefined uiButton']/span").click();
		
		return this;
	}
	
	
	public SalesForce_ProductPage clickNewOpportunity()
	{
		driver.findElementByXPath("//div[text()='New Opportunity']").click();
		return this;
	}
	
	public SalesForce_ProductPage enterOpportunityDetails()
	{

		driver.findElementByXPath("//span[text()='Opportunity Name']/following::input").sendKeys("Test opportunity");
		driver.findElementByXPath("//span[text()='Opportunity Name']/following::input[2]").sendKeys("b",Keys.TAB);
		
		LocalDate today=LocalDate.now();
		int date=today.getDayOfMonth();
		
		int s=date+1;
		driver.findElementByXPath("//a[@class='datePicker-openIcon display']").click();
		driver.findElementByXPath("//td[@class='uiDayInMonthCell']/span[text()='"+s+"']").click();
		
		driver.findElementByXPath("(//a[text()='--None--'])[2]").click();
		
		WebElement stage=driver.findElementByXPath("//a[text()='Needs Analysis']");
		
		builder.moveToElement(stage).click().perform();
		
		driver.findElementByXPath("(//span[text()='Save'])[4]").click();
		
		return this;
	}
	
	public SalesForce_ProductPage clickNewCase()
	{
		driver.findElementByXPath("//div[text()='New Case']").click();
		
		return this;
	}
	
	public SalesForce_ProductPage enterCaseDetails()
	{
		driver.findElementByXPath("//input[@title='Search Contacts']").sendKeys("ramya",Keys.TAB);
		driver.findElementByXPath("(//a[text()='--None--'])[2]").click();
		
		builder.moveToElement(driver.findElementByXPath("//a[text()='New']")).click();
		
		driver.findElementByXPath("(//span[text()='Save'])[4]").click();
		
		return this;
	}
	
}
