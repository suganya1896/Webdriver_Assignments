package base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ProjectSpecificMethods {
	
	
	public RemoteWebDriver driver;
	
	@Parameters("browser")
	@BeforeMethod
	public void startApp(String Browser)
	{
		
		if(Browser.equalsIgnoreCase("chrome"))
		{
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver= new ChromeDriver(options);
		}
		
		else if(Browser.equalsIgnoreCase("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			FirefoxOptions options=new FirefoxOptions();
			
			options.addArguments("--disable-notifications");
			
			driver=new FirefoxDriver(options);
		}
		else if(Browser.equalsIgnoreCase("edge"))
			
		{
			WebDriverManager.edgedriver().setup();
			EdgeOptions options=new EdgeOptions();
			
			options.addArguments("--disable-notifications");
			
			driver=new EdgeDriver(options);
		}
	/*	else
		{
			WebDriverManager.iedriver().setup();
			InternetExplorerOptions options=new InternetExplorerOptions();
			options.a
		} */
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//change the url as per testcase
		//driver.get("https://www.walmart.com/");
				
		//driver.get("https://www.zoomcar.com/chennai/");
		
		//driver.get("https://www.postman.com/");
		driver.get("https://login.salesforce.com/?locale=in");
		
	}
	
	@AfterMethod
	public void closeApp()
	{
		driver.close();
	}
	
	}


