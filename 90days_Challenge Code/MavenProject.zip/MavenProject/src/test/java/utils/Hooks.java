package utils;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;
import steps_definition.BaseClass;

public class Hooks extends BaseClass{
	
	@Before
	public void Login_PreCondition() 
	{
	    WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/login");
		driver.findElementById("username").sendKeys("demosalesmanager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		 driver.findElementByLinkText("Leads").click();
	}
	
	@After
	
	public void logOff_PostCondition()
	{
		driver.close();
	}

}
