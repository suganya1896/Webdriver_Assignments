package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;



@CucumberOptions(features= "src/test/java/features/TC06_MergeLead.feature",glue= {"steps_definition","utils"},
monochrome = true,tags = {"~@smoke"})//,dryRun = true,snippets = SnippetType.CAMELCASE)
public class RunLoginTC extends AbstractTestNGCucumberTests{
	
		

}
