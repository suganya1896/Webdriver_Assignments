package steps_definition;



import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class TC01_Login extends BaseClass{
	
	/*@Given("open the chrome browser")
	public void openBrowser() 
	{
	    WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Given("launch the application url")
	public void launchUral() 
	{
		driver.get("http://leaftaps.com/opentaps/control/login");
	}*/
	
	//add regular expression .* enclosed with () to use same method for accepting multiple test data
     @Given("Enter username as (.*)")
     //pass the data as argument to method
	public void enterUsername(String name) 
	{
		driver.findElementById("username").sendKeys(name);
		
	}
	
    @Given("Enter password as (.*)")
	public void enterPassword(String password) 
	{
      driver.findElementById("password").sendKeys(password);
	}
		
	@When("click on login")
    public void clickLoginButton()
    {
    	driver.findElementByClassName("decorativeSubmit").click();
				
	}
	@But("error message should be displayed")
	public void displayError() {
		System.out.println("error message is displayed");
	}
	
	@Then("Home page should be displayed")
	public void DisplayHomepage() {
		
		System.out.println("login successful");
		
		String Title=driver.getTitle();
		
		if(Title.contains("Leaftaps - TestLeaf Automation Platform"))
		
		System.out.println("title matched: "+Title);

		else
			System.out.println("Title mismatch:"+Title);
		
		Boolean displayed=driver.findElementByLinkText("CRM/SFA").isDisplayed();
		
		if(displayed)
		{
			System.out.println("homepage is dispalyed");
		}
		else
		{
			System.out.println("homepage is not displayed");
		}
		
		
	}
	
}
