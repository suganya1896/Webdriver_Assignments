package steps_definition;

import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC03_EditLead extends BaseClass{

	/*	
	@Given("Click on crmsfa link")
	public void clickOnCrmsfaLink() {
	 
		driver.findElementByLinkText("CRM/SFA").click();
		
	}
	 @Given("click on leads tab")
		public void clickLeads() {
	    	
	       driver.findElementByLinkText("Leads").click();
	       } */

	@Given("click on find lead sub tab")
	public void clickOnFindLeadSubTab() {
        driver.findElementByXPath("(//ul[@class='shortcuts']//a)[3]").click();
		
		System.out.println("find lead page title:"+driver.getTitle());
	}

	@Given("Enter firstName of existing lead (.*)")
	public void enterFirstNameOfExistingLead(String name) {
	   
		driver.findElementByXPath("(//div[@class='allSubSectionBlocks']//input)[2]").sendKeys(name);
		
	}

	@When("click on find leads button")
	public void clickOnFindLeadsButton() throws InterruptedException {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
				 
	}

	@Then("Respective lead entry should be displayed")
	public void respectiveLeadEntryShouldBeDisplayed() {
		String lead=driver.findElementByXPath("(//div[@class='x-grid3-scroller']//a)").getText();
		System.out.println("searched lead id:"+lead);
	}

	@Given("click on that lead from search result")
	public void clickOnThatLeadFromSearchResult() {
		driver.findElementByXPath("(//div[@class='x-grid3-scroller']//a)").click();
	}

	@Given("Click on Edit button")
	public void clickOnEditButton() {
		driver.findElementByLinkText("Edit").click();
	}

	@Given("Change the company name (.*)")
	public void changeTheCompanyName(String company) {
		
		WebElement clearcompanyname=driver.findElementById("updateLeadForm_companyName");
		clearcompanyname.clear();
		clearcompanyname.sendKeys(company);
	}

	@When("Click on update")
	public void clickOnUpdate() {
		driver.findElementByXPath("(//div[@class='fieldgroup']//input)[15]").click();
		
	    
	}

	@Then("company name should be changed successfully")
	public void companyNameShouldBeChangedSuccessfully() {
		
      WebElement company=driver.findElementByXPath("//span[@id='viewLead_companyName_sp']");
		
		String companyname=company.getText();
		
		System.out.println("changed company name"+companyname);
	}

}
