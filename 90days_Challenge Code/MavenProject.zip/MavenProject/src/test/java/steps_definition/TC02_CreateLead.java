package steps_definition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC02_CreateLead extends BaseClass{
	
	/*@Given("click on crmsfa link")
	public void clickcrmsfa() {
		
		driver.findElementByLinkText("CRM/SFA").click();
			
		}
	
    @Given("click on leads tab")
	public void clickLeads() {
    	
       driver.findElementByLinkText("Leads").click();
       }
    */
	@Given("click on create lead in subtab of leads tab")
	public void clickCreateLead() {
		driver.findElementByLinkText("Create Lead").click();
		}
	
	@Given("Enter the company name (.*)")
	public void enterCompanyName(String company) {
		driver.findElementById("createLeadForm_companyName").sendKeys(company);
			}
	@Given("Enter the first name (.*)")
	public void enterFirstName(String Fname) {
		driver.findElementById("createLeadForm_firstName").sendKeys(Fname);
			}
	@Given("Enter the last name (.*)")
	public void enterLastName(String Lname)
	{
		driver.findElementById("createLeadForm_lastName").sendKeys(Lname);
	}
	@Given("Enter the Area Code (.*)")
	public void enterAreaCode(String AreaCode)
	{
		driver.findElementById("createLeadForm_primaryPhoneAreaCode").sendKeys(AreaCode);
		
	}
	@Given("Enter the Phone number (.*)")
	public void enterPhoneNumber(String Phone)
	{
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys(Phone);
		
	}
	@Given("Enter the Email (.*)")
	public void enterEmail(String email)
	{
		driver.findElementById("createLeadForm_primaryEmail").sendKeys("abc@gmail.com");
	}
	@When("Click on create lead button")
	public void clickSubmit()
	{
		//click on submit button to create new lead
				driver.findElementByName("submitButton").click();
				
	}
	
	@Then("lead should be created successfully")
	public void verifyCL()
	{
		System.out.println("lead is created successfully"+driver.getTitle());
		
		String firstName=driver.findElementByXPath("//span[@id='viewLead_firstName_sp']").getText();
		
		System.out.println("Created new Lead name"+firstName);
			
			
	}
	
}


