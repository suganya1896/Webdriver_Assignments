package steps_definition;

import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC05_DuplicateLead extends BaseClass{
	public String Lname,Dupname;
	
	@Given("click on find leads tab")
	public void clickOnFindLeadTab() {
		
		driver.findElementByXPath("(//ul[@class='shortcuts']//a)[3]").click();
		
	}
	
	@Given("click on email tab under find leads page")
	public void clickEmailTab()
	{
		driver.findElementByXPath("//span[text()='Email']").click();
		
	}
	@Given("Enter Email id (.*)")
	public void enterEmail(String email)
	{

		driver.findElementByXPath("(//label[text()='Email Address:']/following::input)").sendKeys(email);
		
	}
	
	
	
	@Given("click on first resulting lead from search result")
	public void clickOnFirstLeadFromSearchResult() {
		driver.findElementByXPath("(//div[@class='x-grid3-scroller']//a)").click();;
		
	}

	@Given("capture name of lead selected")
	public void captureName()
	{
		WebElement leadname=driver.findElementByXPath("//span[@id='viewLead_firstName_sp']");
		 Lname=leadname.getText();
	System.out.println("lead name to be duplicated:"+Lname);
	}
	@Given("click on duplicate button")
	public void clickDuplicate()
	{
		 driver.findElementByXPath("//div[@class='frameSectionExtra']/a").click();
			
	}
	
	@Given("capture firstname of lead in duplicate page")
	public void duplicateName() throws InterruptedException
	{
       WebElement duplicateLName=driver.findElementByXPath("//input[@id='createLeadForm_firstName']");
		
		 Dupname=duplicateLName.getAttribute("value");
		Thread.sleep(1000);
	}
	
	@When("click on create lead button")
	public void clickCreate()
	{

		driver.findElementByXPath("//input[@value='Create Lead']").click();
		
	}
	
	@Then("duplicate lead should be created")
	public void verify()
	{
		if(Dupname.contains(Lname))
		{
			System.out.println("Captured Duplicate name is matched");
		}
		else
		{
			System.out.println("Captured Duplicate name is not matched");
		}
	}
}
