package steps_definition;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	//static keyword is used to share driver object across all class
	public static ChromeDriver driver;

}
