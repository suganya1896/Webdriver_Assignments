package steps_definition;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC06_MergeLead extends BaseClass{
	
	public String fromleadText;
	
	@Given("Click on merge lead subtab")
	public void clickMergeLead()
	{
		driver.findElementByLinkText("Merge Leads").click();
	}
	@Given("Click on Icon near From Lead")
	public void clickFromLead()
	{
		driver.findElementByXPath("//table[@name='ComboBox_partyIdFrom']/following-sibling::a").click();
		
	}
	@Given("Click Find Leads button in from lead page")
	public void clickFindFrom() throws InterruptedException
	{
      Set<String> set=driver.getWindowHandles();
		
	   List<String> list=new ArrayList<String>(set);
				
		for (String eachvalue : set) {
			list.add(eachvalue);
		}
		
		//switch to new opened window upon clicking from lead
		driver.switchTo().window(list.get(1));
					
		//Click Find Leads button
		driver.findElementByXPath("//button[text()='Find Leads']").click();
				
		Thread.sleep(3000);
				
	}
	
	@Given("Click First Resulting lead")
	public void clickFirstFromLead()
	{
		//locating 10th lead in table
		 fromleadText=driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[10]").getText();
			System.out.println(fromleadText);
			
		
		//Click on the located Resulting lead
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[10]").click();
		//Switch back to primary window
		Set<String> set=driver.getWindowHandles();
		
		   List<String> list=new ArrayList<String>(set);
				
	 	driver.switchTo().window(list.get(0));
				
	}
	
	@Given("Click on Icon near To Lead")
	public void clickToLead()
	{
		driver.findElementByXPath("//table[@id='widget_ComboBox_partyIdTo']/following-sibling::a").click();
        Set<String> win2ref=driver.getWindowHandles();
		
		List<String> list2=new ArrayList<String>(win2ref);
		
		for (String eachval2 : win2ref) {
			list2.add(eachval2);
			
		}
		//switching to child window
				driver.switchTo().window(list2.get(1));
	}
	
	
	@Given("click on first resulting lead id from table")
	public void clickFirstToLead()
	{
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[5]").click();
		
		Set<String> s=driver.getWindowHandles();
		List<String> l=new ArrayList<String>(s);
		//switching control to parent window
		driver.switchTo().window(l.get(0));
	}
	@When("click on merge button")
	public void clickMerge()
	{
		driver.findElementByXPath("//a[text()='Merge']").click();
	}
	@Then("click on ok in alert pop-up")
	public void alert()
	{
		//switch to alert window popup
		Alert popup=driver.switchTo().alert();
		//click on ok in alert pop-up
		popup.accept();
	}
	
	@Given("enter from lead id")
	public void fromLeadID()
	{
		driver.findElementByXPath("//input[@name='id']").sendKeys(fromleadText);
	}
	
	
	@Then("Verify two leads got merged successfully")
	public void verify()
	{
		System.out.println(driver.findElementByXPath("//div[@class='x-paging-info']").getText());
		
	}
	
}
