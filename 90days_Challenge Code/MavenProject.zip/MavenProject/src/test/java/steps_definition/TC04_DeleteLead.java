package steps_definition;

import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class TC04_DeleteLead extends BaseClass{
	
	public String LeadID;
	
	@Given("click on find lead tab")
	public void clickOnFindLeadTab() {
		
		driver.findElementByXPath("(//ul[@class='shortcuts']//a)[3]").click();
		
	}

	@Given("click on phone tab under find leads page")
	public void clickOnPhoneTabUnderFindLeadsPage() {
		
		driver.findElementByXPath("//span[text()='Phone']").click();
		
	}

	@Given("Enter the area code (.*)")
	public void enterTheAreaCodeArea_Code(String area) {
		driver.findElementByXPath("//input[@name='phoneAreaCode']").sendKeys(area);
		    
	}

	@Given("Enter the phone number (.*)")
	public void enterThePhoneNumber(String phone) {
		
		driver.findElementByXPath("//input[@id='ext-gen270']").sendKeys(phone);
				
	}
	
 
	@Given("Lead with searched phone number should be displayed")
	public void leadWithSearchedPhoneNumberShouldBeDisplayed() {
		WebElement lead=driver.findElementByXPath("(//div[@class='x-grid3-scroller']//a)");
		LeadID=lead.getText();
		
		System.out.println("Id of first lead :"+LeadID);
		
	}

	@Given("click on first lead from search result")
	public void clickOnFirstLeadFromSearchResult() {
		driver.findElementByXPath("(//div[@class='x-grid3-scroller']//a)").click();;
		
	}

	@Given("click on delete button")
	public void clickOnDeleteButton() {
		driver.findElementByXPath("//a[text()='Delete']").click();
		 
	}

	@Given("click on find leads subtab")
	public void clickOnFindLeadsSubtab() {
		driver.findElementByXPath("(//ul[@class='shortcuts']//a)[3]").click();
	}

	@Given("Enter deleted lead id")
	public void enterDeletedLeadId() {
		driver.findElementByXPath("(//label[text()='Lead ID:']/following::input)").sendKeys(LeadID);
		
	}
	
	@Then("Deleted Lead should not be present")
	public void deletedLeadShouldNotBePresent() {
	
		System.out.println(driver.findElementByXPath("//*[@id='ext-gen437']").getText());

	}



}
