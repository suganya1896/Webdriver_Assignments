package testng.day2;



import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;



public class CreateLead extends LoginAndLogoff{

	@Test
	public  void createLead()  throws InterruptedException {
		
		
		driver.findElementByLinkText("Leads").click();
		
		driver.findElementByLinkText("Create Lead").click();
		
		driver.findElementById("createLeadForm_companyName").sendKeys("Amzaon");
		driver.findElementById("createLeadForm_firstName").sendKeys("caroline2");
		driver.findElementById("createLeadForm_lastName").sendKeys("kalus");
		
	    WebElement	source= driver.findElementById("createLeadForm_dataSourceId");
		Select dropdownsrc=new Select(source);
		
		dropdownsrc.selectByVisibleText("Employee");
		
		WebElement marketing=driver.findElementById("createLeadForm_marketingCampaignId");
		Select dropdownmark=new Select(marketing);
		dropdownmark.selectByIndex(2);
		
		WebElement industry=driver.findElementById("createLeadForm_industryEnumId");
		Select dropdownindust=new Select(industry);
		//to get all options present in drop down
		List<WebElement> options=dropdownindust.getOptions();
		//storing size of dropdown in variable
		int size=options.size();
		
	    dropdownindust.selectByIndex(size-2);
		
	    
	    WebElement ownership=driver.findElementById("createLeadForm_ownershipEnumId");
		Select dropdownowner=new Select(ownership);
		
		dropdownowner.selectByIndex(5);
		
		
		WebElement	country= driver.findElementById("createLeadForm_generalCountryGeoId");
		Select dropdowncountry=new Select(country);
		
		dropdowncountry.selectByVisibleText("India");
		//add phonenumber,area code
		driver.findElementById("createLeadForm_primaryPhoneAreaCode").sendKeys("91");
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys("1234567890");
		
		//add email
		
		driver.findElementById("createLeadForm_primaryEmail").sendKeys("abc@gmail.com");
		//click on submit button to create new lead
		driver.findElementByName("submitButton").click();
		
		
		System.out.println(driver.getTitle());
	}
		@Test
		public void display() 
		{
			System.out.println("hello");
			
		}
		
		
	}
	
