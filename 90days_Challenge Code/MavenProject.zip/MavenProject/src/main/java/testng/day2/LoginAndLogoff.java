package testng.day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginAndLogoff {
	
	public static ChromeDriver driver;
	
	
	@BeforeMethod
	
	public void login() throws InterruptedException
	{
	
	WebDriverManager.chromedriver().setup();
	
	driver=new ChromeDriver();
	
	driver.get("http://leaftaps.com/opentaps/control/login");
	
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	driver.findElementById("username").sendKeys("demosalesmanager");
	driver.findElementById("password").sendKeys("crmsfa");
	
	driver.findElementByClassName("decorativeSubmit").click();
	
	System.out.println("login successful");
	
	System.out.println(driver.getTitle());
	
	driver.findElementByLinkText("CRM/SFA").click();
	
	System.out.println(driver.getTitle());
	
	}
	
	@AfterMethod
	public void logOff()
	{
		driver.close();
	
	}
	

}
