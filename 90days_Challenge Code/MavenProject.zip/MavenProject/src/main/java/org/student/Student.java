package org.student;

import org.department.Department;

public class Student extends Department{
	
	public void studentName(String stuname)
	{
		System.out.println("student name:"+stuname);
	}
	
	public void studentDept(String dept)
	{
		System.out.println("Student Department:"+dept);
	}
	
	public void studentId(int id)
	{
		System.out.println("student id:"+id);
	}

	public static void main(String[] args) {
		
		Student s=new Student();
		s.collegeName("Sairam Engineering College");
		s.collegeCode(4125);
		s.collegeRank(2);
		s.deptName("Computer Science and Engineering");
		s.studentName("Suganya");
		s.studentDept("cse-section A");
		s.studentId(4125001);
		

	}

}
