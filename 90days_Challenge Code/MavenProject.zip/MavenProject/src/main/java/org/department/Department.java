package org.department;

import org.college.College;

public class Department extends College{

	public void deptName(String deptname)
	{
		System.out.println("department name:"+deptname);
	}
	
}
