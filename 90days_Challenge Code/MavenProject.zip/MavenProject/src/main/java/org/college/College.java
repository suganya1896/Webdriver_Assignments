package org.college;


public class College {
	
	public void collegeName(String clgname)
	{
		System.out.println("college name:"+clgname);
	}
	
	public void collegeCode(int code)
	{
		System.out.println("college code:"+code);
	}

	public void collegeRank(int rank)
	{
		System.out.println("college rank:"+rank);
	}
}
