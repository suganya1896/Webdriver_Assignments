package oopsconceptsweek3;

public interface Software {

	void softwareResources();
}
