package oopsconceptsweek3;

public interface Hardware {
	
	void hardwareResources();

}
