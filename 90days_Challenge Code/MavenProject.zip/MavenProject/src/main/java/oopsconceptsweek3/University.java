package oopsconceptsweek3;

public abstract class University {

	public void pg() {
		System.out.println("PG");

	}
	 abstract void ug();
	
}
