package oopsconceptsweek3;

public class AndroidPhone extends Mobile{

	
	public void takeVideo() {
		
	System.out.println("video has taken in android phone");
	
	}

}

