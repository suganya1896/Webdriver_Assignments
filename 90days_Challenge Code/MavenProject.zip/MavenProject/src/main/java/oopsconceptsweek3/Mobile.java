package oopsconceptsweek3;

public class Mobile {

	public void sendMSG()
	{
		System.out.println("message send");
	}
public void makeCall() {
	System.out.println("call has made");

}

public void saveContact() {
	System.out.println("contact saved");
}

}
