package javabasics1;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CharOccurance {

	public static void main(String[] args) {

		String str = "welcome to chennai";
		 /* 
		 * int count=0;
		 * 
		 * char[] arr=str.toCharArray(); int length=arr.length;
		 * System.out.println("length of an given arrary:"+length);
		 * 
		 * for(int i=0;i<arr.length-1;i++) { if(arr[i]== 'e') { count++; }
		 * 
		 * } System.out.println("occurrence of character e:"+count);
		 * 
		 * public static void main(String[] args) {
		 */

		 
	    //Create a HashMap 
	    Map<Character, Integer> map = new HashMap<Character, Integer>(); 
	 
	    //Convert the String to char array
	    char[] chars = str.replaceAll(" ", "").trim().toCharArray();
	 
	    /* logic: char are inserted as keys and their count
	     * as values. If map contains the char already then
	     * increase the value by 1
	     */
	    for(Character ch:chars){
	      if(map.containsKey(ch)){
	         map.put(ch, map.get(ch)+1);
	      } else {
	         map.put(ch, 1);
	        }
	    }
	 
	    //Obtaining set of keys
	    Set<Character> keys = map.keySet();
	 
	    /* Display count of chars if it is
	     * greater than 1. All duplicate chars would be 
	     * having value greater than 1.
	     */
	    for(Character ch:keys){
	     // if(map.get(ch) > 1){
	        System.out.println("Char "+ch+" "+map.get(ch));
	     // }
	    }
	  }

	}


