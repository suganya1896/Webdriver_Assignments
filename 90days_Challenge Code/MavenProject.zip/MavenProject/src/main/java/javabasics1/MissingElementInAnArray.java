package javabasics1;

import java.util.Arrays;

public class MissingElementInAnArray {

	public static void main(String[] args) {
		int[] arr = {1,2,3,4,7,6,8,9,11,14};

		Arrays.sort(arr);
		int first=arr[0];
		int next =first+1;
      
	
	for (int i=0;i<arr.length;i++)
      {
			if((Arrays.binarySearch(arr, next))!=arr[i])
			{
				System.out.println("Missing number is "+arr[i]);
				break;
			}
    	  }
			
		}
		
		
	}
	
		/* while(nextValue<=last)
		 {
			// if (Arrays.binarySearch(arr, nextValue)<0))
{

}
	*/	 



