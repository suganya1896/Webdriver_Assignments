package seleniumweek4.day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DeleteIncidentServiceNowTC {

	public static void main(String[] args) throws InterruptedException {
	  /*WebDriverManager.iedriver().setup()
      		InternetExplorerDriver driver=new InternetExplorerDriver();*/
		
		 WebDriverManager.chromedriver().setup();
			
			ChromeDriver driver=new ChromeDriver();
				
		//launch the browser
		driver.get("https://dev68594.service-now.com/");
		//maximize the window
		driver.manage().window().maximize();
				
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//login section is present inside iframe .. so first switch to frame to login 
		driver.switchTo().frame(0);
		
		//Enter username as �admin�
		driver.findElementByXPath("//input[@id='user_name']").sendKeys("admin");
		//Enter password as �India@123�
		driver.findElementByXPath("//input[@id='user_password']").sendKeys("India@123");
		//Click on Login
		
		driver.findElementByXPath("//button[text()='Login']").click();
		
		//Search �incident � in Filter Navigator
		WebElement search=driver.findElementByXPath("//input[@id='filter']");
		search.sendKeys("incident");
		//after entering input ,click on enter button in keyboard
		search.sendKeys(Keys.ENTER);
		//wait for 2sec to load the page
		Thread.sleep(1000);
		//click on "all" option in left sidse of page
		driver.findElementByXPath("(//div[text()='All'])[2]").click();
		
		driver.switchTo().frame(0);
		
		
		//select search type from drop down as "number"
		
				WebElement searchNo=driver.findElementByXPath("//select[@class='form-control default-focus-outline']");
				Select dd2=new Select(searchNo);
				dd2.selectByVisibleText("Number");
				
				//enter incident no in next text field
				
				WebElement incidentNo=driver.findElementByXPath("//input[@class='form-control']");
				
				incidentNo.sendKeys("INC0014159",Keys.ENTER);
				Thread.sleep(1000);
				
				//click on incident 
				
				WebElement first=driver.findElementByXPath("(//tbody[@class='list2_body']//a)[2]");
				String deletedncident=first.getText();
				System.out.println("deleted incident no:"+deletedncident);
				first.click();
				
				//click on delete button
				driver.findElementByXPath("//button[text()='Delete']").click();
				Thread.sleep(1000);
				//click on delete in sweet alert window
				driver.findElementByXPath("//button[text()='Delete']").click();
				
				incidentNo.sendKeys(deletedncident,Keys.ENTER);
				
				System.out.println("incident is deleted confirmation message:"+driver.findElementByXPath("//tr[@class='list2_no_records']/td").getText());
	
	}

}
