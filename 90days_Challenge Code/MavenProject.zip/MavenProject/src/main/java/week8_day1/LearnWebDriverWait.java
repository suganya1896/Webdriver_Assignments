package week8_day1;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnWebDriverWait {

	public static void main(String[] args) {
		
		
      WebDriverManager.chromedriver().setup();
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.get("http://leafground.com/pages/TextChange.html");
		
		//maximize the window of above url page
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		WebElement ele=driver.findElementByXPath("//button[@id='btn']");
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		
		wait.until(ExpectedConditions.textToBePresentInElement(ele, "Click ME!"));
		
		ele.click();
		Alert a=driver.switchTo().alert();
		a.accept();
		
		/*if((ele.getText()).equalsIgnoreCase("click me"))
				{
			System.out.println("element is meatched");
				}
		else
		{
			System.out.println("element is mismatch");
		}*/
		
		System.out.println(ele.getText());
		
		driver.close();
		
		
		
		
	}

}
