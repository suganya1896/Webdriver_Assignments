package week8_day1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TakeScreenshot {

	public static void main(String[] args) throws IOException {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		
		driver.get("http://leafground.com/pages/Window.html");
		
		driver.findElementByXPath("//button[@id='home']").click();
		
		Set<String> WinSet=driver.getWindowHandles();
		List<String> WinList=new ArrayList<String>(WinSet);
		
		driver.switchTo().window(WinList.get(1));
		driver.manage().window().maximize();
		//take screenshot of opened window
		File source=driver.getScreenshotAs(OutputType.FILE);
		
		//target location to save the captured screenshot
		
		File target=new File("./snapshot/window1.png");
		
		//copying the captured screenshot from source to target location
		
		FileUtils.copyFile(source, target);
		
		
		driver.quit();
		
		
		
		
	}

}
