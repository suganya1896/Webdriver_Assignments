package week8_day1;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {
		//to create a physical html report
		
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./ExtentReports/result.html");
		
		//to maintain the history of execution 
		
		reporter.setAppendExisting(true);
		
		// to get the actual report
		
		ExtentReports extent=new ExtentReports();
		
		//to integrate the physical file to actual report
		
		extent.attachReporter(reporter);
		
		//to create a testcase with tc details
		
		ExtentTest testcase=extent.createTest("LoginandLogout", "login");
		
		//to declare who has written code i.e author
		
		testcase.assignAuthor("suganya");
		//to declare what type of testing we are doing for this test case
		//i.e whether we r executing as part of functional,smoke,regressing testing
		
		testcase.assignCategory("smoke");
		
		//to get report for step level execution status
		
		testcase.pass("username is entered successfully");
		testcase.pass("password is entered successfully");
		testcase.pass("user has logged in successfully");
		
		//to fail testcase
		testcase.fail("login failed");
		
		//to attach the screenshot to report 
		//here ../ mentioned in path represent to come out of extent reports folder & get inside snapshot folder to attach screenshot
		
		testcase.pass("username is entered successfully", MediaEntityBuilder.createScreenCaptureFromPath(".././snapshot/username.png").build());
	
	//to have all the information in report , must provide below line of code at the end of program
		extent.flush();
	
	}

}
