package testngexercise.day1;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class MergeLeadTestCase extends LoginAndLogoff{
	
	@Test(enabled = false)//it will skip this test case if set enabled attribute as false
	
	
	public  void mergeLead() throws InterruptedException {
		
		//click on leads tab
		driver.findElementByLinkText("Leads").click();
		
		//click on merge lead sub tab
		driver.findElementByLinkText("Merge Leads").click();
		 //Click on Icon near From Lead
		driver.findElementByXPath("//table[@name='ComboBox_partyIdFrom']/following-sibling::a").click();
		
		Set<String> set=driver.getWindowHandles();
		
		List<String> list=new ArrayList<String>(set);
		
		
		for (String eachvalue : set) {
			list.add(eachvalue);
		}
			
		String mainwinref=list.get(0);	
		String openedWinRef=list.get(1);
		
		System.out.println("child window of from lead:"+openedWinRef);
		//switch to new opened window upon clicking from lead
		driver.switchTo().window(openedWinRef);
		/*// enter lead id 
		WebElement fromleadId=driver.findElementByXPath("//div[@class='x-form-element']/input");
		fromleadId.sendKeys("10110"); */
		
		//Click Find Leads button
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		
		Thread.sleep(3000);
		
		WebElement firstId=driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[12]");
		
		String fromleadText=firstId.getText();
		System.out.println(fromleadText);
		//Click on Resulting lead
		firstId.click();
		
			
		//Switch back to primary window
		
		driver.switchTo().window(mainwinref);
		
		
		//Click on Icon near To Lead
		
		driver.findElementByXPath("//table[@id='widget_ComboBox_partyIdTo']/following-sibling::a").click();
		
		Thread.sleep(2000);
     
		Set<String> win2ref=driver.getWindowHandles();
		
		List<String> list2=new ArrayList<String>(win2ref);
		
		for (String eachval2 : win2ref) {
			list2.add(eachval2);
			
		}
		//parent window
		String w1=list2.get(0);
		//child window
		String w2=list2.get(1);
		//switching to child window
		driver.switchTo().window(w2);
		/*Thread.sleep(1000);
		//enter lead id			
		driver.findElementByXPath("//label[text()='Lead ID:']/following::input").sendKeys("10121"); */
		//click on find leads button
				
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
		//click on first resulting lead id from table
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[6]").click();
		//switching control to parent window
		driver.switchTo().window(w1);
		//click on merge button
		driver.findElementByXPath("//a[text()='Merge']").click();;
		//switch to alert window popup
		Alert popup=driver.switchTo().alert();
		//click on ok in alert pop-up
		popup.accept();
		
		//click on find leads
		driver.findElementByLinkText("Find Leads").click();
		//enter from lead id
		driver.findElementByXPath("//input[@name='id']").sendKeys(fromleadText);
		//click on find leads button
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
		//conforming no records to display text
		System.out.println(driver.findElementByXPath("//*[@id='ext-gen437']").getText());
		
	}

}
