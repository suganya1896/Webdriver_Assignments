package testngexercise.day1;



import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class CreateLead extends LoginAndLogoff{
	
	@DataProvider(name="Lead")
	public String[][] getLead()
	{
		String[][] array=new String[2][6];
		
		array[0][0]="Amazon";
		array[0][1]="caroline2";
		array[0][2]="kalus";
		array[0][3]="91";
		array[0][4]="2567946525";
		array[0][5]="abc@gmail.com";
		
		array[1][0]="IBM";
		array[1][1]="damon";
		array[1][2]="salvatore";
		array[1][3]="91";
		array[1][4]="2567946523";
		array[1][5]="abc@gmail.com";
		
		
		return array;
		
		
	}
	@DataProvider(name="lead1")
	public static String[][] getPhoneNumber()
	
	{
		String[][] phone= new String[2][2];
		
		phone[0][0]= "91";
		phone[0][1]= "2567946525";
		phone[1][0]= "91";
		phone[1][1]= "2567946523";
		
		
			return phone;
		
	}
	@Test(dataProvider = "Lead")
	public void createLead(String company,String firstname,String LastName,String AreaCode,String phone,String email) throws InterruptedException {
				
		driver.findElementByLinkText("Leads").click();
		
		driver.findElementByLinkText("Create Lead").click();
		
		driver.findElementById("createLeadForm_companyName").sendKeys(company);
		driver.findElementById("createLeadForm_firstName").sendKeys(firstname);
		driver.findElementById("createLeadForm_lastName").sendKeys(LastName);
		
	    WebElement	source= driver.findElementById("createLeadForm_dataSourceId");
		Select dropdownsrc=new Select(source);
		
		dropdownsrc.selectByVisibleText("Employee");
		
		WebElement marketing=driver.findElementById("createLeadForm_marketingCampaignId");
		Select dropdownmark=new Select(marketing);
		
		dropdownmark.selectByValue("9001");
		
		WebElement industry=driver.findElementById("createLeadForm_industryEnumId");
		Select dropdownindust=new Select(industry);
		//to get all options present in drop down
		List<WebElement> options=dropdownindust.getOptions();
		//storing size of dropdown in variable
		int size=options.size();
		
	    dropdownindust.selectByIndex(size-2);
		
	    
	    WebElement ownership=driver.findElementById("createLeadForm_ownershipEnumId");
		Select dropdownowner=new Select(ownership);
		
		dropdownowner.selectByIndex(5);
		
		
		WebElement	country= driver.findElementById("createLeadForm_generalCountryGeoId");
		Select dropdowncountry=new Select(country);
		
		dropdowncountry.selectByVisibleText("India");
		//add phonenumber,area code
		driver.findElementById("createLeadForm_primaryPhoneAreaCode").sendKeys(AreaCode);
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys(phone);
		
		//add email
		
		driver.findElementById("createLeadForm_primaryEmail").sendKeys(email); 
		//click on submit button to create new lead
		driver.findElementByName("submitButton").click();
		
		
		System.out.println(driver.getTitle());
		
		
		
	}
	}
