package pages;

import java.util.Properties;

import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;


public class FindLeadPage extends ProjectCommonMethods{
	

	public FindLeadPage(RemoteWebDriver driver,Properties prop) {
		
		this.driver=driver;
		this.prop=prop;
		
	}
	
	public FindLeadPage enterFirstNameOfExistingLead(String name) {
	   
		driver.findElementByXPath(prop.getProperty("findleadpage.firstname.Xpath")).sendKeys(name);
		
		return this;
		
	}
	public FindLeadPage clickOnFindLeadsButton() throws InterruptedException {
		
		driver.findElementByXPath(prop.getProperty("findleadpage.clickfind.Xpath")).click();
		Thread.sleep(2000);
		
		return this;
	}

	public ViewLeadPage clickOnleadId() {
		WebElement lead=driver.findElementByXPath(prop.getProperty("findleadpage.clicklead.Xpath"));
		LeadID=lead.getText();
		
		System.out.println("Id of first lead :"+LeadID);
		
		lead.click();
		return new ViewLeadPage(driver,prop);
	}

  
	public FindLeadPage clickOnPhoneTab() {
		
		driver.findElementByXPath(prop.getProperty("findleadpage.phonetab.Xpath")).click();
		return this;
	}

	
	public FindLeadPage enterAreaCode(String area) {
		driver.findElementByXPath(prop.getProperty("findleadpage.areacode.Xpath")).sendKeys(area);
		 return this;   
	}


	public FindLeadPage enterPhoneNo(String phone) {
		
		driver.findElementByXPath(prop.getProperty("findleadpage.phone.Xpath")).sendKeys(phone);
		return this;
				
	}
	
	public FindLeadPage enterDeletedLeadId() {
		driver.findElementByXPath(prop.getProperty("findleadpage.deletedLeadId.Xpath")).sendKeys(LeadID);
		return this;
	}
	
	public FindLeadPage verifyDeletedlead() {
		
		System.out.println("verifying lead id is deleted:"+driver.findElementByXPath(prop.getProperty("findleadpage.verifydeletedLead.Xpath")).getText());

	return this;
	}
	
	public FindLeadPage enterFromLeadID()
	{
		driver.findElementByXPath(prop.getProperty("findleadpage.fromlead.Xpath")).sendKeys(fromleadText);
		return this;
	}

	public FindLeadPage verifyMerge()
	{
		//conforming no records to display text
				System.out.println("verifying merged from lead id is not displayed:"
		+driver.findElementByXPath(prop.getProperty("findleadpage.verifymerge.Xpath")).getText());
		return this;		
	}
	
	public FindLeadPage enterEmail()
	{
		driver.findElementByXPath(prop.getProperty("findleadpage.emailTab.Xpath")).click();

		driver.findElementByXPath(prop.getProperty("findleadpage.email.Xpath")).sendKeys("abc@gmail.com");
		
		return this;
	}
	
	
}
