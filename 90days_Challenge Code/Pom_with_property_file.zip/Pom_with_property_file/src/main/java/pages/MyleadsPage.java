package pages;

import java.util.Properties;

//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class MyleadsPage extends ProjectCommonMethods {
	
	public MyleadsPage(RemoteWebDriver driver,Properties prop)
	{
		this.driver=driver;
		this.prop=prop;
	}
	
  public CreateLeadPage clickCreateLead()
  {
	driver.findElementByLinkText(prop.getProperty("MyleadsPage.CreateLead.Linktext")).click();
	
	return new CreateLeadPage(driver,prop);
	
  }
  
  public FindLeadPage clickFindlead()
  {
	  driver.findElementByXPath(prop.getProperty("MyleadsPage.FindLead.Xpath")).click();
		
	  return new FindLeadPage(driver,prop);
  }
  
  public MergeLeadPage clickMergelead()
  {
	  driver.findElementByLinkText(prop.getProperty("MyleadsPage.MergeLead.Linktext")).click();
		
	  return new MergeLeadPage(driver,prop);
  }
  
  

}
