package pages;


import java.util.Properties;

//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;


public class CreateLeadPage extends ProjectCommonMethods {
	
	
	public CreateLeadPage(RemoteWebDriver driver,Properties prop) 
	{
	
		this.driver=driver;
		this.prop=prop;
	
	}
		
	public CreateLeadPage enterCompanyName(String company) {
		driver.findElementById(prop.getProperty("CreateLeadPage.company.Id")).sendKeys(company);
			
		return this;
	}

	public CreateLeadPage enterFirstName(String Fname)
	{
		driver.findElementById(prop.getProperty("CreateLeadPage.firstname.Id")).sendKeys(Fname);
		
		firstname=driver.findElementById(prop.getProperty("CreateLeadPage.firstname.Id")).getText();
		
		
		return this;
	}
	
	
	public CreateLeadPage enterLastName(String Lname) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElementById(prop.getProperty("CreateLeadPage.lastname.Id")).sendKeys(Lname);
		return this;
	}
	
	public CreateLeadPage enterAreaCode(String AreaCode)
	{
		driver.findElementById(prop.getProperty("CreateLeadPage.areacode.Id")).sendKeys(AreaCode);
		return this;
		
	}
	
	public CreateLeadPage enterPhoneNumber(String Phone)
	{
		driver.findElementById(prop.getProperty("CreateLeadPage.phonenumber.Id")).sendKeys(Phone);
		return this;
		
	}
	
	public CreateLeadPage enterEmail(String email)
	{
		driver.findElementById(prop.getProperty("CreateLeadPage.email.Id")).sendKeys(email);
		return this;
	}
	
	public ViewLeadPage clickSubmit()
	{
		//click on submit button to create new lead
				driver.findElementByName(prop.getProperty("CreateLeadPage.submit.Name")).click();
				return new ViewLeadPage(driver,prop);
				
	}
	
}
	
	   
	