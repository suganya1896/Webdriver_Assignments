package pages;


import java.util.Properties;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class Loginpage extends ProjectCommonMethods{
	
	public Loginpage(RemoteWebDriver driver,Properties prop)
	{
		this.driver=driver;
		this.prop=prop;
	}
	
	public Loginpage enterUsername() 
	{
		driver.findElementById(prop.getProperty("Loginpage.username.Id")).sendKeys("demosalesmanager");
		
		//declare  return statement where control should go
		//return this means swtiching control to login page itself .i.e we are in the same page after enter username that y we r using this keyword
		return this; 
		
	}
	
	public Loginpage enterPassword() 
	{
      driver.findElementById(prop.getProperty("Loginpage.password.Id")).sendKeys("crmsfa");
      
      return this;
	}
	
	 public HomePage clickLoginButton()
	  {
	    	driver.findElementByClassName(prop.getProperty("Loginpage.Login.Classname")).click();
	    	
	    	return new HomePage(driver,prop);
					
	  }
	 
	 

}
