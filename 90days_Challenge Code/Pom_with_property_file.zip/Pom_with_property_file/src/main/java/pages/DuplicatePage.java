package pages;

import java.util.Properties;

import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class DuplicatePage extends ProjectCommonMethods{
	
	public DuplicatePage(RemoteWebDriver driver,Properties prop) {
		
		this.driver=driver;
		this.prop=prop;
	}

	
	public ViewLeadPage clickCreate() throws InterruptedException
	{
		//capture firstname of lead in duplicate page
		
		WebElement duplicateLName=driver.findElementByXPath(prop.getProperty("duplicatepage.dupLeadname.Xpath"));
			
		DLname=duplicateLName.getAttribute("value");
		System.out.println("lead name after duplicating:"+DLname);
		Thread.sleep(1000);
		driver.findElementByXPath(prop.getProperty("duplicatepage.create.Xpath")).click();
		
		return new ViewLeadPage(driver,prop);
	}
}
