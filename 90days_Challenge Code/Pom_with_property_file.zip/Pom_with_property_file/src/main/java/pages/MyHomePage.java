package pages;

import java.util.Properties;

//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class MyHomePage extends ProjectCommonMethods{
	
	public MyHomePage(RemoteWebDriver driver,Properties prop)
	{
		this.driver=driver;
		this.prop=prop;
	}
	
	public MyleadsPage clickLeads()
	{
		driver.findElementByLinkText(prop.getProperty("MyHomePage.leads.Linktext")).click();
		
		return new MyleadsPage(driver,prop);
	}

}
