package pages;

import java.util.Properties;

import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class EditLeadPage extends ProjectCommonMethods{
	
	public EditLeadPage(RemoteWebDriver driver,Properties prop) {
		
		this.driver=driver;
		this.prop=prop;
	}



	public EditLeadPage updateCompanyName(String company) {
		
		WebElement clearcompanyname=driver.findElementById(prop.getProperty("editleadpage.updatecompany.Id"));
		clearcompanyname.clear();
		clearcompanyname.sendKeys(company);
		return this;
	}

	
	public ViewLeadPage clickOnUpdate() {
		driver.findElementByXPath(prop.getProperty("editleadpage.clickupdate.Xpath")).click();
		
		return new ViewLeadPage(driver,prop);
	    
	}
}
