package pages;

import java.util.Properties;

import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class ViewLeadPage extends ProjectCommonMethods{
	
	
	public ViewLeadPage(RemoteWebDriver driver,Properties prop)
	{
		this.driver=driver;
		this.prop=prop;
	}
	
	public ViewLeadPage verifyLead()
	
	{   String nameview=driver.findElementById(prop.getProperty("viewleadpage.firstname.Id")).getText();
	
	if(nameview.contains(firstname))
	{
		System.out.println("lead is created successfully"+firstname+"created lead name:"+nameview);
	}
		boolean name=driver.findElementById(prop.getProperty("viewleadpage.firstname.Id")).isDisplayed();
		
		if(name)
			System.out.println("name is displayed :"+firstname);
		else
			System.out.println("name is blank:"+firstname);
		
		return this;
	}
	

	public EditLeadPage ClickEdit()
	{
		
	driver.findElementByLinkText(prop.getProperty("viewleadpage.edit.Linktext")).click();
	return new EditLeadPage(driver,prop);		
	}
	
	public ViewLeadPage verifyCompanyName()
	{	
		     WebElement company=driver.findElementByXPath(prop.getProperty("viewleadpage.companyname.Xpath"));
				
			 String companyname=company.getText();
				
			 System.out.println("changed company name"+companyname);
			return this;
	}
	
	public MyleadsPage clickDelete()
	{
		driver.findElementByXPath(prop.getProperty("viewleadpage.delete.Xpath")).click();
		
		return new MyleadsPage(driver,prop);
		
	}
	public DuplicatePage clickDuplicate() throws InterruptedException
		{
		
		//capture name of lead selected
		
		WebElement leadname=driver.findElementByXPath(prop.getProperty("viewleadpage.Lname.Xpath"));
		 Lname=leadname.getText();
		 System.out.println("lead name before duplicating:"+Lname);
          Thread.sleep(1000);
		  driver.findElementByLinkText(prop.getProperty("viewleadpage.duplicate.Linktext")).click();
			
		return new DuplicatePage(driver,prop);
		
	}
	
	public void verifyDuplicate()
	{

		if(DLname.contains(Lname))
		{
			System.out.println("original name "+Lname+" and Duplicate name is matched:"+DLname);
		}
		else
		{
			System.out.println("Captured Duplicate name is not matched");
		}
	}
	
}
