package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class MergeLeadPage extends ProjectCommonMethods{
	
	
	
	public MergeLeadPage(RemoteWebDriver driver,Properties prop)
	{
		this.driver=driver;
		this.prop=prop;
	}

	
	public MyleadsPage mergeLead() throws InterruptedException
	{
		//Click on Icon near From Lead
				driver.findElementByXPath(prop.getProperty("MergeLeadpage.clickfrom.Xpath")).click();
				
				Set<String> set=driver.getWindowHandles();
				
				List<String> list=new ArrayList<String>(set);
					
				String mainwinref=list.get(0);	
				String openedWinRef=list.get(1);
				
				//switch to new opened window upon clicking from lead
				driver.switchTo().window(openedWinRef);
				
				//Click Find Leads button
				WebElement find =driver.findElementByXPath(prop.getProperty("MergeLeadpage.findlead.Xpath"));
				find.click();
				
				Thread.sleep(2000);
				
				WebElement firstId=driver.findElementByXPath(prop.getProperty("MergeLeadpage.clickfromId.Xpath"));
				
				 fromleadText=firstId.getText();
				System.out.println("from lead Id :"+fromleadText);
				//Click on Resulting lead
				firstId.click();
				
					
				//Switch back to primary window
				
				driver.switchTo().window(mainwinref);
				
				
				//Click on Icon near To Lead
				
				driver.findElementByXPath(prop.getProperty("MergeLeadpage.clickTo.Xpath")).click();
				
				Thread.sleep(2000);
		     
				Set<String> win2ref=driver.getWindowHandles();
				
				List<String> list2=new ArrayList<String>(win2ref);
				
				for (String eachval2 : win2ref) {
					list2.add(eachval2);
					
				}
				//parent window
				String w1=list2.get(0);
				//child window
				String w2=list2.get(1);
				//switching to child window
				driver.switchTo().window(w2);
				/*Thread.sleep(1000);
				//enter lead id			
				driver.findElementByXPath("//label[text()='Lead ID:']/following::input").sendKeys("10121"); */
				//click on find leads button
						
				driver.findElementByXPath(prop.getProperty("MergeLeadpage.findlead.Xpath")).click();
				Thread.sleep(2000);
				//click on first resulting lead id from table
				driver.findElementByXPath(prop.getProperty("MergeLeadpage.clickToId.Xpath")).click();
				//switching control to parent window
				driver.switchTo().window(w1);
				//click on merge button
				driver.findElementByXPath(prop.getProperty("MergeLeadpage.merge.Xpath")).click();;
				//switch to alert window popup
				Alert popup=driver.switchTo().alert();
				//click on ok in alert pop-up
				popup.accept();
				
		return new MyleadsPage(driver,prop);
	}
	
	
	
}
