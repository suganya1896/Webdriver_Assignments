package pages;

import java.util.Properties;

//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectCommonMethods;

public class HomePage extends ProjectCommonMethods{
	
	public HomePage(RemoteWebDriver driver,Properties prop) {
		
		this.driver=driver;
		this.prop=prop;
	
	}
	
	public Loginpage logOut()
	{
		driver.findElementByClassName(prop.getProperty("HomePage.logout.Classname")).click();
	    return new Loginpage(driver,prop);		
	}
	
	public MyHomePage clickLink()
	{
		driver.findElementByLinkText(prop.getProperty("HomePage.link.Linktext")).click();
		
		return new MyHomePage(driver,prop);
	}

}
