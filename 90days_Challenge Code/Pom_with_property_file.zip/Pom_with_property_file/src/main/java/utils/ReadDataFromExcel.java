package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ReadDataFromExcel {
	
	public String[][] readExcel(String SheetName) throws IOException  {

	//getting into  excel file by mentioning path
      XSSFWorkbook wb = new XSSFWorkbook("E:\\Testleaf_updated Doc\\RACSSR\\src\\main\\java\\utills\\Dataprovider.xlsx");
    //getting into respective sheet
        XSSFSheet ws=wb.getSheet(SheetName);
        
        //to get no of rows count excluding header use below method
    	int rowsCount=ws.getLastRowNum();
    	//to get no of cells count..first moving to 1st row by using getRow(0) & counting no of column by using below method
    	int cellsCount=ws.getRow(0).getLastCellNum();
    	
    	//create an empty 2d array to store cells values
    	
    	String[][] data=new String[rowsCount][cellsCount];
    	
        //iterate through cells to access values in excel
    	//i=1 means referring 2nd row excel where data present
    	for(int i=1;i<=rowsCount;i++)
    	{
    		for(int j=0;j<cellsCount;j++)
    		{
    			String Cellvalue=ws.getRow(i).getCell(j).getStringCellValue();
    			data[i-1][j]=Cellvalue;
    		}
    	}
        wb.close();
        
        return data;
      
	}
	
  
}