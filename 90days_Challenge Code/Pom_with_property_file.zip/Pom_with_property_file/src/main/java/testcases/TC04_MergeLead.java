package testcases;

import org.testng.annotations.Test;

import base.ProjectCommonMethods;
import pages.Loginpage;

public class TC04_MergeLead extends ProjectCommonMethods{
	
	@Test
	public void mergeLead() throws InterruptedException
	{
		new Loginpage(driver,prop).enterUsername().enterPassword().clickLoginButton()
		.clickLink().clickLeads().clickMergelead().mergeLead().clickFindlead().enterFromLeadID().clickOnFindLeadsButton()
		.verifyMerge();

}
}