package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectCommonMethods;
import pages.Loginpage;


public class TC02_EditLead extends ProjectCommonMethods{
	
	
  @BeforeTest
   public void setSheetName()
	{
		excelSheetName="EditLead";
	}
  
	@Test(dataProvider = "fetchdata")//, dependsOnMethods = "testcases.TC01_CreateLead.addLead")
	public void editlead(String firstname,String company) throws InterruptedException
	{
		new Loginpage(driver,prop)
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickLink()
		.clickLeads()
		.clickFindlead()
		.enterFirstNameOfExistingLead(firstname)
		.clickOnFindLeadsButton()
		.clickOnleadId()
		.ClickEdit()
		.updateCompanyName(company)
		.clickOnUpdate()
		.verifyCompanyName();
	}

}
