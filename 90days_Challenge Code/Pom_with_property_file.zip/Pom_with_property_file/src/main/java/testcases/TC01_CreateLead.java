package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectCommonMethods;
import pages.Loginpage;



public class TC01_CreateLead extends ProjectCommonMethods{
	
	@BeforeTest
	public void setSheetName()
	{
		excelSheetName="CreateLead";
	}
	
	@Test(dataProvider = "fetchdata")
	public void addLead(String company,String firstname,String lastname,String areacode,String phone,String email) throws InterruptedException
	
	{
		new Loginpage(driver,prop)
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickLink()
		.clickLeads().clickCreateLead().enterCompanyName(company).enterFirstName(firstname)
		.enterLastName(lastname).enterAreaCode(areacode).enterPhoneNumber(phone).enterEmail(email).clickSubmit().verifyLead();
	
		
	}

}
