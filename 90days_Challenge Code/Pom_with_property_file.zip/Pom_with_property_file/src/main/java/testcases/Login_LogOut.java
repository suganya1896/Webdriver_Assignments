package testcases;

import org.testng.annotations.Test;

import base.ProjectCommonMethods;

import pages.Loginpage;

@Test
public class Login_LogOut extends ProjectCommonMethods{
	
	
	public void login()
	{
		//instead of creating new object for class to access all methods & to save a memory, we can directly use keyword "new" which will create constructor 
		 new Loginpage(driver,prop).enterUsername().enterPassword().clickLoginButton().logOut();
	}

}
