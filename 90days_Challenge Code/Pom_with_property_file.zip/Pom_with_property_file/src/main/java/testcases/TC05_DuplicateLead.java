package testcases;

import org.testng.annotations.Test;

import base.ProjectCommonMethods;
import pages.Loginpage;

public class TC05_DuplicateLead extends ProjectCommonMethods {
	
	@Test
	public void duplicateLead() throws InterruptedException
	{
		new Loginpage(driver,prop).enterUsername().enterPassword().clickLoginButton()
		.clickLink().clickLeads().clickFindlead().enterEmail().clickOnFindLeadsButton().clickOnleadId().clickDuplicate()
		.clickCreate().verifyDuplicate();
	}

}
