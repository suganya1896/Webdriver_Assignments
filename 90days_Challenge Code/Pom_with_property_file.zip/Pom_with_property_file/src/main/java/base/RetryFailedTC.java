package base;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryFailedTC implements IRetryAnalyzer{

	//declaring max count to no of times rerun failed cases( here have declared as 3 to rerun failed cases 3 times)
			int maxcount=3;
			int retrycount=0;
			
	public boolean retry(ITestResult result) {
		
		if((!result.isSuccess()) && (retrycount < maxcount))
		{
			retrycount++;
			return true;
		}
		
		return false;
		
			
	}

}
