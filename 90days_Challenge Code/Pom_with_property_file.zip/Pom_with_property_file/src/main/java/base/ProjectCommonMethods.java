package base;

import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
//import testcases.ReadDataFromExcel;
import utils.ReadDataFromExcel;

public class ProjectCommonMethods {

	//declare common driver object to share across all other class
	public RemoteWebDriver driver;
	
	/*when we declare driver obj as static we cann't run testcases parallely using testTG
	 *to execute multiple testcases in paralell ,do the following steps to share driver obj
	 *First remove "static" keyword from driver object in base class
	 *create constructor in each pages class with ChromeDriver as argument
	 *Then pass driver in all constructor call
	 *  */
	public static String firstname;
	public String excelSheetName;
	
	//declare a common object for property file to share across all other classes
	
	public Properties prop;
	
	public static String fromleadText;
	
	public static String LeadID;
	public static String Lname;
	public static String DLname;
	
	//declare common methods to start each testcase i.e create browserInvoke & browserClose methods
	@Parameters({"url","browser","language"})
	@BeforeMethod
	public void browserInvoke(String url,String browser,String language) throws IOException
	{
		//to setup a property file path
		FileInputStream fs =new FileInputStream("./src/main/resources/"+language+".properties");
		//create a object for properties file to access it
		prop=new Properties();
		//to load the properties file for interaction
		prop.load(fs);
		
		//browser invocation
		if(browser.equalsIgnoreCase("chrome"))
		{
		WebDriverManager.chromedriver().setup();
		
		driver=new ChromeDriver();
				
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
		WebDriverManager.firefoxdriver().setup();
		
		driver=new FirefoxDriver();
		
		}
		else if(browser.equalsIgnoreCase("Edge"))
		{
		WebDriverManager.edgedriver().setup();
		driver=new EdgeDriver();
		}
		
        driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	}
	
	@AfterMethod
	public void browserClose()
	{
		driver.close();
	}
	
	@DataProvider(name="fetchdata")
	public String[][]  sendData() throws IOException
	{
		//creating obj for readexcel class to access method present inside that class
		ReadDataFromExcel readData=new ReadDataFromExcel();
		//accessing method by using obj
		String[][] data=readData.readExcel(excelSheetName);
		//return data value to data provider method which will passed to testases
		return data;
		
		
	}

}
