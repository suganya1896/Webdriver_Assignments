package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class PostMan_HomePage extends ProjectSpecificMethods{
	
	public PostMan_HomePage(RemoteWebDriver driver) {
		
		this.driver=driver;
	}
	
	
	public PostMan_HomePage clickSignIn()
	{
		
		driver.findElementByLinkText("Sign In").click();
		return this;
	}

	public PostMan_HomePage enterUsername()
	{
		driver.findElementById("username").sendKeys("DhivyaTestleaf");
		return this;
	}
	
	public PostMan_HomePage enterPassword()
	{
		driver.findElementById("password").sendKeys("India@123");
		return this;
	}
	
	
	public PostMan_BuildPage clickLogin() throws InterruptedException
	{
		driver.findElementById("sign-in-btn").click();
		Thread.sleep(4000);
		return new PostMan_BuildPage(driver);
		
	}
}
