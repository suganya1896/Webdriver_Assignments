package pages;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class PostMan_BuildPage extends ProjectSpecificMethods{
	
	
	public PostMan_BuildPage(RemoteWebDriver driver) {
		
	this.driver=driver;
	
	}
	public static String  ColName;
	public static String RequestName;
	
	public PostMan_BuildPage clickNew() throws InterruptedException
	{
		
		driver.findElementByXPath("//button[text()='Create New']").click();
		Thread.sleep(2000);
		WebElement newreq=driver.findElementByXPath("//div[text()='New']");
		//=driver.findElementByXPath("//div[text()='New']");
		//WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(20));
		//wait.until(ExpectedConditions.elementToBeClickable(newreq));
		//newreq.click();
		Actions builder =new Actions(driver);
		builder.moveToElement(newreq).click().perform();
		return this;
	}
	
	public PostMan_BuildPage clickCollections()
	{
		driver.findElementByXPath("//div[text()='Collection']").click();
		return this;
	}


	public PostMan_BuildPage clickEditIcon()
	{
		driver.findElementByXPath("//div[@class='btn btn-icon entity-tab-header__edit-btn']").click();
		
		return this;
	}
public PostMan_BuildPage enterColName()
{
	
	WebElement CN=driver.findElementByXPath("//div[@class='entity-tab-header__name__input']");
	CN.clear();
	CN.sendKeys("sample collection test");
	
	ColName=CN.getText();
	return this;
}

public PostMan_BuildPage clickRun()
{
	driver.findElementByXPath("//div[text()='Run']").click();
	return this;
}

public PostMan_BuildPage navigateToCollection()
{
		
	WebElement des=driver.findElementByXPath("//div[text()='Collections']");
	
	des.click();
	return this;
}

public PostMan_BuildPage clickViewOfColOptions()
{
	WebElement CC=driver.findElementByXPath("//div[text()='"+ColName+"']");
	
	Actions builder=new Actions(driver);
	
	builder.moveToElement(CC).perform();
	//issue in locating view options
	
	driver.findElementByXPath("//div[text()='"+ColName+"']/following::i[3]").click();
	return this;
	
}

public PostMan_BuildPage clickAddReq()
{
	driver.findElementByXPath("//div[text()='Add Request']").click();
	
	return this;
}


public PostMan_BuildPage enterReqName()
{
	WebElement reqname=driver.findElementByXPath("(//span[@class='breadcrumb__name'])[2]");
	reqname.clear();
	reqname.sendKeys("sample request for testing",Keys.ENTER);
	
	RequestName=reqname.getText();
	return this;
}

public PostMan_BuildPage verifyRequest()
{
	String req=driver.findElementByXPath("(//div[text()='"+ColName+"']/following::div)[12]").getText();
	
	if(req.contains(ColName))
		System.out.println("Request has been created successfully"+req);
	
	else
		System.out.println("Request hasn't created"+req);
	
	return this;
}
}
