package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class Walmart_WomenShoesPage extends ProjectSpecificMethods{
	
	public Walmart_WomenShoesPage(RemoteWebDriver driver) {
		
	this.driver=driver;	
	}

	
	
	public Walmart_WomenShoesPage clickComfortShoes()
	{
		driver.findElementByXPath("(//a[text()='Comfort Shoes'])[3]").click();
		return this;
	}


 public Walmart_WomenShoesPage clickSneakers()
 {
	 driver.findElementByXPath("//a[text()='Sneakers']").click();
	 
	 return this;
 }
 
 
 public void getLowPriceProduct()
 {
	 //locating all product title 
	 
	 List<WebElement> Title=driver.findElementsByXPath("//span[@class='product-brand']/strong");
	 //printing size of list containing the product titles 
	System.out.println("No of products available in page:"+Title.size());
	//looping through all products to pick only "flexx" & "Propet" brand
	
	for(int i=0;i<Title.size();i++)
	{
		//if element present inside list has visible text as "flex" & "propet" ,then add that product to map
		
	String product=	Title.get(i).getText();
	
	 if(product.equalsIgnoreCase("The Flexx")||product.equalsIgnoreCase("Propet"))
	 {
		//Map<String,String>	PDetails=new 
         
         
	 
	 }
 }
}
}
