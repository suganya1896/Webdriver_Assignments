package pages;

import java.time.Duration;
import java.time.LocalDate;
import java.time.Month;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;

public class Airbnb_HomePage extends ProjectSpecificMethods{
	
	public Airbnb_HomePage(RemoteWebDriver driver) {
		
		this.driver=driver;
	
	}
	
	public  LocalDate today; 
	
	public Airbnb_HomePage clickOk()
	{
		WebElement clickOk=driver.findElementByXPath("(//button[text()='OK'])[2]");
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		
		wait.until(ExpectedConditions.elementToBeClickable(clickOk)).click();
		
		return this;
	}
	
	public WebElement enterLocation(String location) throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElementByXPath("//div[text()='Location']/following-sibling::input").sendKeys(location);
		
		WebElement locatebagaBeach=driver.findElementByXPath("//div[text()='Baga Beach, Baga']"); 
				
		return locatebagaBeach;
	}

	
	public int getDate()
	{
		today=LocalDate.now();
		
		int Date=today.getDayOfMonth();
		
		return Date;
	}
	
	public int getYear()
	{
		int year=today.getYear();
		return year;
	}
	
	public int getMonth()
	{
		int month=today.getMonthValue();
		
		return month;
	}
	
	public Airbnb_HomePage clickCheckIn()
	{
		WebElement checkIn=driver.findElementByXPath("//div[@role='button']");
		
		checkIn.click();
		return this;
	}
	public WebElement selectCheckInDate(int currentDateofMonth) throws InterruptedException
	
	{
		int date=currentDateofMonth+10;
		Thread.sleep(1000);
		WebElement bookingDate=driver.findElementByXPath("//div[@class='_1lds9wb']//table//div[text()='"+date+"']");
		return bookingDate;
	
	}
public Airbnb_HomePage moveToElement(WebElement ele)
{
	Actions builder=new Actions(driver);
	builder.moveToElement(ele).click().perform();

	return this;
}

public String getCheckInDate()
{
	String CheckInDate=driver.findElementByXPath("//div[@class='_p4vcro6']").getText();
	
	return CheckInDate;
}

public String getCheckOutDate()
{
	String CheckOutDate=driver.findElementByXPath("//div[@class='_vuaqekp']").getText();
	
	return CheckOutDate;
}
public WebElement selectCheckOutDate(int currentDateofMonth)
{
	int checkOutDate=currentDateofMonth+15;
	WebElement bookingDate=driver.findElementByXPath("//div[@class='_1lds9wb']//table//div[text()='"+checkOutDate+"']");
	
return bookingDate;
}
	

public Airbnb_HomePage  clickCheckBox()
{
	//WebElement checkbox=driver.findElementByXPath("//input[@id='flexible-dates-checkbox-flexible-dates-flexible_date_search_filter_type-row-checkbox']/following-sibling::span");
//checkbox.click();

	driver.findElementByXPath("//label[@for='flexible-dates-flexible_date_search_filter_type-2']").click();
	
	//driver.findElementByXPath("//span[@class='_167krry']").click();
 return this;
}

public Airbnb_HomePage selectMydatesFLX()
{
	WebElement e=driver.findElementByXPath("//select[@id='flexible-dates-menu']");
	Select options=new Select(e);
	options.selectByValue("1");
return this;	
}
	
public Airbnb_HomePage clickAddGuest()
{
	driver.findElementByXPath("//div[text()='Add guests']").click();
	
	return this;
}

public Airbnb_HomePage addAdults_Kids()
{
	for(int i=0;i<=1;i++)
	{
		//adding 2 adults as guest
	driver.findElementByXPath("(//button[@class='_7hhhl3']/span)[2]").click();
	}
//adding 1 kid as guest	
driver.findElementByXPath("(//div[@data-testid='search-block-filter-stepper-row-stepper-children']//button)[2]").click();

return this;
}

 public Airbnb_BagaBeachPage clickSearch()
 {
	driver.findElementByXPath("//span[@class='_163rr5i']").click();
	return new Airbnb_BagaBeachPage(driver);
 }


}
