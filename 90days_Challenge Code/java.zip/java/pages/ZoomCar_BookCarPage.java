package pages;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections4.map.HashedMap;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class ZoomCar_BookCarPage extends ProjectSpecificMethods{
	
    String choosenDate;
	String highestPriceCar;
	public ZoomCar_BookCarPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public ZoomCar_BookCarPage clickStartLoc()
	{
		driver.findElementByXPath("//div[@class='items'][3]").click();
		
		return this;
	}

	public ZoomCar_BookCarPage clickNext()
	{
		driver.findElementByXPath("//button[text()='Next']").click();
		return this;
	}

public ZoomCar_BookCarPage selectDate()
{
	WebElement date=driver.findElementByXPath("//div[@class='day']");
	choosenDate=date.getText();
	System.out.println("choosen pick up date:"+choosenDate);
	date.click();
	return this;
	
}

public ZoomCar_BookCarPage confirmSelectedDate()
{
	String date=driver.findElementByXPath("//div[@class='label time-label']").getText();
	System.out.println("date in drop time page:"+date);
	if(date.contains(choosenDate))
	System.out.println("Choosen date matched");
	else
		System.out.println("Choosen Date is incorrect");
	return this;	
}

public ZoomCar_BookCarPage clickDone()
{
	driver.findElementByXPath("//button[text()='Done']").click();
	
	return this;
}

public ZoomCar_BookCarPage getCarDetail_Price() throws InterruptedException
{
	Thread.sleep(5000);
	List<WebElement> CarName=driver.findElementsByXPath("//div[@class='details']/h3");
	List<WebElement> price=driver.findElementsByXPath("//div[@class='price']");
	int s=CarName.size();
	System.out.println(s);
	Map<String,String> mapcar=new HashMap<>();
	
	for(int i=0;i<s;i++)
	{
		
	mapcar.put(CarName.get(i).getText(), price.get(i).getText());
	
	}
	
	for (Entry<String, String> eachCar : mapcar.entrySet()) {
		System.out.println(eachCar);
	}
	
	 highestPriceCar=Collections.max(mapcar.values()).substring(1, 7);
	System.out.println("price of car:"+highestPriceCar);
	//System.out.println(mapcar.keySet());
	return this;
}

public ZoomCar_BookCarPage clickBookNow() throws InterruptedException
{
	
	WebElement bookNow=driver.findElementByXPath("//div[contains(text(),'"+highestPriceCar+"')]/following-sibling::button");
	//JavascriptExecutor js=(JavascriptExecutor)driver;
	System.out.println(bookNow);
	//js.executeScript("arguments[0].click();",bookNow);
	Actions builder =new Actions(driver);
	builder.moveToElement(bookNow).click().perform();
	
	Thread.sleep(10000);
	return this;
}


}



