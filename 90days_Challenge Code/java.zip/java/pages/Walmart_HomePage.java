package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class Walmart_HomePage extends ProjectSpecificMethods {
	
	public Walmart_HomePage(RemoteWebDriver driver) {
	
	this.driver=driver;
	
	}

	public Walmart_HomePage clickMenu()
	{
		driver.findElementByXPath("//button[@id='header-Header-sparkButton']//img").click();
		
		return this;
	}
	
	public Walmart_HomePage moveToElement(WebElement ele)
	{
		Actions builder=new Actions(driver);
		builder.moveToElement(ele).click().perform();

		return this;
	}
	
	
	public WebElement clickClothing()
	{
		WebElement cloth=driver.findElementByXPath("//span[text()='Clothing, Shoes & Accessories']");
		return cloth;
	
	}
	
	public Walmart_WomenShoesPage clickShoes()
	{
		WebElement shoes=driver.findElementByXPath("//div[text()='Shoes']");
		
		Actions builder=new Actions(driver);
		builder.moveToElement(shoes).click().perform();

		return new Walmart_WomenShoesPage(driver);
	}
	
	
}
