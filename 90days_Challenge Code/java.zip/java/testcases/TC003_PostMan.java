package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.PostMan_HomePage;

public class TC003_PostMan extends ProjectSpecificMethods {
	
	
	@Test
	
	public void Addrequest() throws InterruptedException
	{
		new PostMan_HomePage(driver).clickSignIn().enterUsername().enterPassword().clickLogin()
		.clickNew()
		.clickCollections()
		.clickEditIcon()
		.enterColName()
		.clickRun().navigateToCollection()
		.clickViewOfColOptions().clickAddReq().clickEditIcon().enterReqName().verifyRequest();
		
	
	}

}
