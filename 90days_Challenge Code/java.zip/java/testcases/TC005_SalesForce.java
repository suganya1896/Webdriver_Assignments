package testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.SalesForceLoginPage;
import pages.SalesForce_HomePage;

public class TC005_SalesForce extends ProjectSpecificMethods{
	
	
	@Test
	public void createProducts() throws InterruptedException
	{
		WebElement viewAll= new SalesForceLoginPage(driver)
				.enterUsername()
				.enterPassword()
				.clickLogin()
		        .clickMenu();
		
		WebElement SC=new SalesForce_HomePage(driver).MoveToElement(viewAll).clickServiceConsole();
		
		WebElement productDD=new SalesForce_HomePage(driver).MoveToElement(SC).clickAppMenu().selectProduct();
		
		new SalesForce_HomePage(driver).MoveToElement(productDD)
		.clickNew()
		.enterProductDetails()
		.capturePopUpMSG()
		.verifyProductname()  //getting IllegalArgumentException(driver must set) & ctrl is not transfering to next page for executing method 
		.clickNewContact()
		.enterContactDetails()
		.clickSave()
		.clickNewOpportunity()
		.enterOpportunityDetails()
		.clickNewCase()
		.enterCaseDetails();
		
	}

}
